import 'package:flutter/material.dart';
import '../../data/models/raw_material.dart';
import '../../data/repositories/raw_material_repository.dart';
import 'material_form_screen.dart';

class MaterialScreen extends StatefulWidget {
  const MaterialScreen({super.key});

  @override
  State<MaterialScreen> createState() => _MaterialScreenState();
}

class _MaterialScreenState extends State<MaterialScreen> {
  final RawMaterialRepository _repo = RawMaterialRepository();
  List<RawMaterial> _materials = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _isLoading = true);
    _materials = await _repo.getAll();
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المواد الخام')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MaterialFormScreen())).then((_) => _load()),
        child: const Icon(Icons.add),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _materials.isEmpty
              ? const Center(child: Text('لا توجد مواد'))
              : ListView.builder(
                  itemCount: _materials.length,
                  itemBuilder: (context, index) {
                    final material = _materials[index];
                    return ListTile(
                      title: Text(material.name),
                      subtitle: Text('${material.unit} | ${material.purchasePrice}'),
                    );
                  },
                ),
    );
  }
}