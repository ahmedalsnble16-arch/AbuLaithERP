import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../../core/database/database_helper.dart';
import '../../data/models/raw_material.dart';
import '../../data/repositories/raw_material_repository.dart';

class MaterialFormScreen extends StatefulWidget {
  final RawMaterial? material;
  const MaterialFormScreen({super.key, this.material});

  @override
  State<MaterialFormScreen> createState() => _MaterialFormScreenState();
}

class _MaterialFormScreenState extends State<MaterialFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _unitController = TextEditingController(text: 'كيلو');
  final _priceController = TextEditingController();
  final _repo = RawMaterialRepository();
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    if (widget.material != null) {
      _nameController.text = widget.material!.name;
      _unitController.text = widget.material!.unit;
      _priceController.text = widget.material!.purchasePrice.toString();
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);
    final now = DateTime.now().toIso8601String();
    final material = RawMaterial(
      id: widget.material?.id ?? const Uuid().v4(),
      name: _nameController.text,
      unit: _unitController.text,
      purchasePrice: double.tryParse(_priceController.text) ?? 0,
      createdAt: widget.material?.createdAt ?? now,
      updatedAt: now,
    );
    if (widget.material == null) {
      await _repo.add(material);
    }
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.material == null ? 'إضافة مادة' : 'تعديل مادة')),
      body: Form(
        key: _formKey,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          TextFormField(controller: _nameController, decoration: const InputDecoration(labelText: 'الاسم')),
          TextFormField(controller: _unitController, decoration: const InputDecoration(labelText: 'الوحدة')),
          TextFormField(controller: _priceController, decoration: const InputDecoration(labelText: 'سعر الشراء'), keyboardType: TextInputType.number),
          const SizedBox(height: 20),
          ElevatedButton(onPressed: _isSaving ? null : _save, child: const Text('حفظ')),
        ]),
      ),
    );
  }
}